package myproject_catering;

import java.util.ArrayList;
import java.util.List;

public class Logistics {
    private final List<Delivery> deliveries;

    public Logistics() {
        this.deliveries = new ArrayList<>();
    }

    public void addDelivery(Delivery delivery) {
        deliveries.add(delivery);
    }

    public List<Delivery> getDeliveries() {
        return deliveries;
    }

    public Delivery trackDelivery(int orderId) {
        return deliveries.stream()
                .filter(delivery -> delivery.getOrderId() == orderId)
                .findFirst()
                .orElse(null);
    }
}

class Delivery {
    private final int orderId;
    private String status;
    private String deliveryDate;
    private String deliveryTime;

    public Delivery(int orderId, String deliveryDate, String deliveryTime) {
        this.orderId = orderId;
        this.deliveryDate = deliveryDate;
        this.deliveryTime = deliveryTime;
        this.status = "Processing"; // Initial status
    }

    public int getOrderId() {
        return orderId;
    }

    public String getStatus() {
        return status;
    }

    public void updateStatus(String status) {
        this.status = status;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }
}