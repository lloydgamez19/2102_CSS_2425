package myproject_catering.customer.OrderSystem;

import java.util.*;
import myproject_catering.Order;
import myproject_catering.customer.Customer;
import myproject_catering.customer.MenuItem;

public class OrderService {
    private static List<MenuItem> menu = new ArrayList<>(); 
    private final List<Order> orders = new ArrayList<>(); 
    private final Map<Integer, List<MenuItem>> customerCarts = new HashMap<>(); // Maps customer IDs to their carts

    public static List<MenuItem> getMenu() {
        return new ArrayList<>(menu); // Return a copy to prevent external modifications
    }

    // Update menu
    public static void setMenu(List<MenuItem> updatedMenu) {
        menu = new ArrayList<>(updatedMenu); // Store a copy to avoid external reference issues
    }

    // Display the menu
    public void displayMenu() {
        System.out.println("\n--- Menu ---");
        if (menu.isEmpty()) {
            System.out.println("The menu is currently empty.");
        } else {
            System.out.printf("%-10s%-30s%-50s%-10s%n", "ID", "Name", "Description", "Price");
            System.out.println("--------------------------------------------------------------------------------");
            for (MenuItem item : menu) {
                System.out.printf("%-10d%-30s%-50s%-10.2f%n", item.getId(), item.getName(), item.getDescription(), item.getPrice());
            }
        }
    }

    public void addMenuItem(Scanner scanner) {
        System.out.print("Enter item name: ");
        String name = scanner.nextLine();
        System.out.print("Enter item description: ");
        String description = scanner.nextLine();
        System.out.print("Enter item price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();

        int id = menu.size() + 1;
        MenuItem newItem = new MenuItem(id, name, description, price);
        menu.add(newItem);
        System.out.println("Menu item added successfully!");
    }

    public void removeMenuItem(Scanner scanner) {
        System.out.print("Enter the ID of the item to remove: ");
        int itemId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        MenuItem itemToRemove = menu.stream().filter(item -> item.getId() == itemId).findFirst().orElse(null);
        if (itemToRemove != null) {
            menu.remove(itemToRemove);
            System.out.println("Menu item removed successfully!");
        } else {
            System.out.println("Invalid item ID. Please try again.");
        }
    }

    public void addOrder(Order order) {
        orders.add(order);
    }

    public List<Order> getOrders() {
        return new ArrayList<>(orders);
    }

    public void addToCart(Scanner scanner, Customer loggedInCustomer) {
        List<MenuItem> cart = customerCarts.getOrDefault(loggedInCustomer.getId(), new ArrayList<>());

        displayMenu();
        System.out.print("\nEnter the Menu Item ID to add to your cart: ");
        
        if (!scanner.hasNextInt()) { 
            System.out.println("Invalid input. Please enter a valid numeric Menu Item ID.");
            scanner.nextLine(); 
            return;
        }
        
        int itemId = scanner.nextInt();
        scanner.nextLine(); 

        MenuItem selectedItem = menu.stream().filter(item -> item.getId() == itemId).findFirst().orElse(null);
        if (selectedItem != null) {
            cart.add(selectedItem);
            
            customerCarts.put(loggedInCustomer.getId(), cart);
            System.out.println(selectedItem.getName() + " has been added to your cart!");

            System.out.print("Any special requests? (Leave blank if none): ");
            String specialRequests = scanner.nextLine();
            if (!specialRequests.isBlank()) {
                System.out.println("Special requests noted: " + specialRequests);
            }
        } else {
            System.out.println("Invalid Menu Item ID. Please try again.");
        }
    }

    public void viewCart(Customer loggedInCustomer) {
        List<MenuItem> cart = customerCarts.getOrDefault(loggedInCustomer.getId(), new ArrayList<>());

        System.out.println("\n--- Your Cart ---");
        if (cart.isEmpty()) {
            System.out.println("Your cart is currently empty.");
        } else {
            System.out.printf("%-10s%-30s%-10s%n", "ID", "Name", "Price");
            for (MenuItem item : cart) {
                System.out.printf("%-10d%-30s%-10.2f%n", item.getId(), item.getName(), item.getPrice());
            }
        }
    }

    public void checkout(Scanner scanner, Customer loggedInCustomer) {
        List<MenuItem> cart = customerCarts.getOrDefault(loggedInCustomer.getId(), new ArrayList<>());

        if (cart.isEmpty()) {
            System.out.println("Your cart is empty. Add items to your cart before checking out.");
            return;
        }

        double totalCost = cart.stream().mapToDouble(MenuItem::getPrice).sum();
        System.out.println("\n--- Checkout ---");
        System.out.printf("Your total is: PHP %.2f%n", totalCost);
        System.out.print("Choose payment method (cash/credit/online): ");
        String paymentMethod = scanner.nextLine().toLowerCase();

        if (paymentMethod.equals("cash") || paymentMethod.equals("credit") || paymentMethod.equals("online")) {
            System.out.print("Enter delivery date (YYYY-MM-DD): ");
            String deliveryDateStr = scanner.nextLine();
            Date deliveryDate = null;
            try {
                deliveryDate = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(deliveryDateStr);
            } catch (java.text.ParseException e) {
                System.out.println("Invalid date format. Please try again.");
                return;
            }

            Order newOrder = new Order(orders.size() + 1, loggedInCustomer.getId(), new ArrayList<>(cart), totalCost, "Pending", paymentMethod);
            newOrder.setDeliveryDate(deliveryDate); 
            addOrder(newOrder);
            customerCarts.put(loggedInCustomer.getId(), new ArrayList<>()); // Clear the cart
            System.out.println("Checkout successful! Your order has been placed.");
        } else {
            System.out.println("Invalid payment method. Checkout canceled. Returning to your cart.");
        }
    }

    public void updateOrderLogistics(int orderId, String status, Date deliveryDate, String location) {
        for (Order order : orders) {
            if (order.getOrderId() == orderId) {
                order.setStatus(status);
                order.setDeliveryDate(deliveryDate);
                order.setLocation(location);
                System.out.println("Order logistics updated successfully.");
                return;
            }
        }
        System.out.println("Order ID not found.");
    }

    public void trackOrders(Customer loggedInCustomer) {
        System.out.println("\n--- Your Orders ---");
        boolean hasOrders = false;
        for (Order order : orders) {
            if (order.getCustomerId() == loggedInCustomer.getId()) {
                System.out.println(order);
                hasOrders = true;
            }
        }

        if (!hasOrders) {
            System.out.println("You have no orders at the moment.");
        }
    }

    public void cancelOrder(int orderId, Customer loggedInCustomer) {
        boolean found = orders.removeIf(order -> order.getOrderId() == orderId && order.getCustomerId() == loggedInCustomer.getId());
        if (found) {
            System.out.println("Order " + orderId + " has been successfully canceled.");
        } else {
            System.out.println("Order not found or does not belong to you.");
        }
    }
}
