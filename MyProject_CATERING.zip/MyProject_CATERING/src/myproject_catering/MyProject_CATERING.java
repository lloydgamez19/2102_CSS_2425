package myproject_catering;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import myproject_catering.customer.Customer;
import myproject_catering.customer.OrderSystem.OrderService;

public class MyProject_CATERING {
    private static final List<Customer> customers = new ArrayList<>();
    private static Admin admin = new Admin(); 
    private static OrderService orderService = new OrderService(); 
    private static int customerIdCounter = 1;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nWelcome to the Catering System.");
            System.out.println("1. Sign Up");
            System.out.println("2. Sign In");
            System.out.println("3. Exit");
            System.out.print("\nChoose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1 -> signUp(scanner);
                case 2 -> signIn(scanner);
                case 3 -> exit = true;
                default -> System.out.println("Invalid choice! Try again.");
            }
        }
    }

    private static void signUp(Scanner scanner) {
        System.out.println("Are you registering as:");
        System.out.println("1. Admin");
        System.out.println("2. Customer");
        System.out.print("Choose an option: ");

        int roleChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (roleChoice) {
            case 1 -> {
                System.out.print("Enter Admin username: ");
                String username = scanner.nextLine();
                System.out.print("Enter Admin password: ");
                String password = scanner.nextLine();

                if (isUsernameExists(username)) {
                    System.out.println("Username already exists. Please choose a different username.");
                    return;
                }

                try (Connection connection = DatabaseConnection.getConnection()) {
                    String sql = "INSERT INTO admin (username, password) VALUES (?, ?)";
                    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                        pstmt.setString(1, username);
                        pstmt.setString(2, password);
                        pstmt.executeUpdate();
                        System.out.println("\nAdmin registration successful!");
                    }
                } catch (SQLException e) {
                    System.out.println("Error during admin registration: " + e.getMessage());
                }
            }
            case 2 -> {
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter address: ");
                String address = scanner.nextLine();
                System.out.print("Enter phone: ");
                String phone = scanner.nextLine();
                System.out.print("Enter username: ");
                String username = scanner.nextLine();
                System.out.print("Enter password: ");
                String password = scanner.nextLine();

                if (isUsernameExists(username)) {
                    System.out.println("Username already exists. Please choose a different username.");
                    return;
                }

                try (Connection connection = DatabaseConnection.getConnection()) {
                    String sql = "INSERT INTO customer (name, address, phone, username, password) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                        pstmt.setString(1, name);
                        pstmt.setString(2, address);
                        pstmt.setString(3, phone);
                        pstmt.setString(4, username);
                        pstmt.setString(5, password);
                        pstmt.executeUpdate();
                        System.out.println("\nCustomer registration successful! You can now sign in.");
                    }
                } catch (SQLException e) {
                    System.out.println("Error during customer registration: " + e.getMessage());
                }
            }
            default -> System.out.println("Invalid choice! Returning to main menu.");
        }
    }

    private static boolean isUsernameExists(String username) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String sql = "SELECT 1 FROM admin WHERE username = ? UNION SELECT 1 FROM customer WHERE username = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, username);
                try (ResultSet rs = pstmt.executeQuery()) {
                    return rs.next();
                }
            }
        } catch (SQLException e) {
            System.out.println("Error checking username existence: " + e.getMessage());
            return false; // Assume username does not exist in case of error
        }
    }

    private static void signIn(Scanner scanner) {
        System.out.println("Are you signing in as:");
        System.out.println("1. Admin");
        System.out.println("2. Customer");
        System.out.print("Choose an option: ");

        int roleChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (roleChoice) {
            case 1 -> signInAsAdmin(scanner);
            case 2 -> signInAsCustomer(scanner);
            default -> System.out.println("Invalid choice! Returning to main menu.");
        }
    }

    private static void signInAsAdmin(Scanner scanner) {
        System.out.print("Enter Admin username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Admin password: ");
        String password = scanner.nextLine();

        try (Connection connection = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("Welcome, Admin!");
                        showAdminMenu(scanner);
                    } else {
                        System.out.println("Invalid admin credentials.");
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error during admin sign-in: " + e.getMessage());
        }
    }

    private static void signInAsCustomer(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        try (Connection connection = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM customer WHERE username = ? AND password = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        String name = rs.getString("name");
                        int id = rs.getInt("id");
                        String address = rs.getString("address");
                        String phone = rs.getString("phone");
                        Customer customer = new Customer(id, name, address, phone, username, password);
                        System.out.println("Welcome, " + name + "!");
                        showCustomerDashboard(scanner, customer);
                    } else {
                        System.out.println("Invalid customer credentials.");
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error during customer sign-in: " + e.getMessage());
        }
    }

    private static void showAdminMenu(Scanner scanner) {
        boolean exit = false;

        while (!exit) {
            System.out.println("\nAdmin Menu:");
            System.out.println("1. Book Management");
            System.out.println("2. Order Management");
            System.out.println("3. Update Order Logistics");
            System.out.println("4. Logout");
            System.out.print("\nChoose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1 -> admin.showMenuManagement(scanner); // Manage menu via Admin class
                case 2 -> showOrderManagement(scanner);
                case 3 -> updateOrderLogistics(scanner);
                case 4 -> exit = true;
                default -> System.out.println("Invalid choice! Try again.");
            }
        }
    }

    private static void showOrderManagement(Scanner scanner) {
        List<Order> orders = orderService.getOrders();
        System.out.println("\n--- Order Management ---");
        if (orders.isEmpty()) {
            System.out.println("No orders available.");
        } else {
            for (Order order : orders) {
                System.out.println(order);
            }
        }
    }

    private static void updateOrderLogistics(Scanner scanner) {
        System.out.print("Enter Order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new Status: ");
        String status = scanner.nextLine();
        System.out.print("Enter new Delivery Date (YYYY-MM-DD): ");
        String deliveryDateStr = scanner.nextLine();
        System.out.print("Enter new Location: ");
        String location = scanner.nextLine();

        try {
            Date deliveryDate = new SimpleDateFormat("yyyy-MM-dd").parse(deliveryDateStr);
            orderService.updateOrderLogistics(orderId, status, deliveryDate, location);
        } catch (java.text.ParseException e) {
            System.out.println("Invalid date format.");
        }
    }

    private static void showCustomerDashboard(Scanner scanner, Customer customer) {
        boolean logout = false;

                    while (!logout) {
                System.out.println("\nCustomer Dashboard:");
                System.out.println("1. View Services");
                System.out.println("2. Add Service");
                System.out.println("3. View added service");
                System.out.println("4. Checkout");
                System.out.println("5. Track Orders");
                System.out.println("6. Logout");
                System.out.print("\nChoose an option: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1 -> orderService.displayMenu();
                    case 2 -> orderService.addToCart(scanner, customer);
                    case 3 -> orderService.viewCart(customer);
                    case 4 -> orderService.checkout(scanner, customer);
                    case 5 -> orderService.trackOrders(customer);
                    case 6 -> {
                        System.out.println("Goodbye, " + customer.getName() + "!");
                        logout = true;
                    }
                    default -> System.out.println("Invalid choice! Try again.");
                }
            }
        }

    }
