
package myproject_catering.customer;

class AbstractStringBuilder {
    
}
