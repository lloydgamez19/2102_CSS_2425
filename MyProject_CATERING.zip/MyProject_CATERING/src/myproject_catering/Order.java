package myproject_catering;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import myproject_catering.customer.MenuItem;

public class Order {
    private final int orderId;
    private final int customerId;
    private final List<MenuItem> orderItems;
    private final double totalCost;
    private String status;
    private String paymentMethod;
    private String feedback;
    private Date deliveryDate; // New field for delivery date
    private String location; // New field for tracking location

    public Order(int orderId, int customerId, List<MenuItem> orderItems, double totalCost, String status, String paymentMethod) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.orderItems = orderItems != null ? orderItems : new ArrayList<>();
        this.totalCost = totalCost;
        this.status = status;
        this.paymentMethod = paymentMethod;
    }

    // Getters and setters
    public int getOrderId() {
        return orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public List<MenuItem> getOrderItems() {
        return orderItems;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public Date getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        StringBuilder itemsStr = new StringBuilder();
        if (orderItems.isEmpty()) {
            itemsStr.append("No items");
        } else {
            for (MenuItem item : orderItems) {
                itemsStr.append("\n- ").append(item.getName()).append(" (PHP ").append(item.getPrice()).append(")");
            }
        }

        return String.format("Order ID: %d\nCustomer ID: %d\nTotal Cost: PHP %.2f\nStatus: %s\nPayment Method: %s\nDelivery Date: %s\nLocation: %s\nFeedback: %s\nItems: %s",
                             orderId, customerId, totalCost, status, paymentMethod, deliveryDate != null ? deliveryDate.toString() : "Not available",
                             location != null ? location : "Not available", feedback != null ? feedback : "No feedback", itemsStr.toString());
    }
}
